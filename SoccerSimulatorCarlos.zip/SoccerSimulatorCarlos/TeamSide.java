public enum TeamSide{
	LEFT, RIGHT
}
