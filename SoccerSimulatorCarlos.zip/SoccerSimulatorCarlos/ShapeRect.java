public interface ShapeRect{
	public float getWidth();
	public float getHeight();
}
