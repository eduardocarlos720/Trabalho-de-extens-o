public interface ShapeCircle{
	public float getRadius();
}
