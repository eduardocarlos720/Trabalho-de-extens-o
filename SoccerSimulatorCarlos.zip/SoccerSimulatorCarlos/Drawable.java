import processing.core.*;
interface Drawable{	
	public void draw(PApplet canvas, float scale);
}
