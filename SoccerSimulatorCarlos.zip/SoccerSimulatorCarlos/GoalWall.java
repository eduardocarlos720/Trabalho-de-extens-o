import processing.core.*;

public class GoalWall extends Goal{

	GoalWall(float x, float y, float w, float h){
		super(x, y, w, h);
	}

}
